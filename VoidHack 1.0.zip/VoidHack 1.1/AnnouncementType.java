package me.earth.earthhack.impl.modules.misc.announcer.util;

public enum AnnouncementType
{
    Distance()
    {
        @Override
        public String getDefaultMessage()
        {
            return "I just mined <NUMBER> Bitches more than you will ever have!";
        }

        @Override
        public String getFile()
        {
            return PATH + "Announcer_Distance.txt";
        }
    },
    Mine()
    {
        @Override
        public String getDefaultMessage()
        {
            return "I just mined <NUMBER> <NAME>!";
        }

        @Override
        public String getFile()
        {
            return PATH + "Announcer_Mine.txt";
        }
    },
    Place()
    {
        @Override
        public String getDefaultMessage()
        {
            return "I just FUCKING placed <NUMBER> <NAME>!";
        }

        @Override
        public String getFile()
        {
            return PATH + "Announcer_Place.txt";
        }
    },
    Eat()
    {
        @Override
        public String getDefaultMessage()
        {
            return "I just devoured <NUMBER> <NAME>!";
        }

        @Override
        public String getFile()
        {
            return PATH + "Announcer_Eat.txt";
        }
    },
    Join()
    {
        @Override
        public String getDefaultMessage()
        {
            return "Welcome idiots <NAME>!";
        }

        @Override
        public String getFile()
        {
            return PATH + "Announcer_Join.txt";
        }
    },
    Leave()
    {
        @Override
        public String getDefaultMessage()
        {
            return "Bye you Fucker <NAME>!";
        }

        @Override
        public String getFile()
        {
            return PATH + "Announcer_Leave.txt";
        }
    },
    Totems()
    {
        @Override
        public String getDefaultMessage()
        {
            return "EZzZzZzZzZ not even trying like absolute trash <NUMBER> Pop <NAME>!";
        }

        @Override
        public String getFile()
        {
            return PATH + "Announcer_Totems.txt";
        }
    },
    Death()
    {
        @Override
        public String getDefaultMessage()
        {
            return "Your absolute dog shit mate <NAME>!";
        }

        @Override
        public String getFile()
        {
            return PATH + "Announcer_Death.txt";
        }
    },
    Miss()
            {
        @Override
        public String getDefaultMessage() {
            return "Your aim is shit <NAME>, if i was standing in place i could have dodged it!";
        }

        @Override
        public String getFile() {
            return PATH + "Announcer_Miss.txt";
        }
    };

    private static final String PATH = "earthhack/util/";

    public abstract String getDefaultMessage();

    public abstract String getFile();

}
