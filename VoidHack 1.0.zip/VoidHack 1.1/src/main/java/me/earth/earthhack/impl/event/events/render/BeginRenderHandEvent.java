package me.earth.earthhack.impl.event.events.render;

import me.earth.earthhack.api.event.events.Event;

public class BeginRenderHandEvent extends Event {}