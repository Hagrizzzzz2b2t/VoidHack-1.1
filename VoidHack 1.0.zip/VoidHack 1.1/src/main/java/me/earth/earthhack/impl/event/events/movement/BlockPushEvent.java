package me.earth.earthhack.impl.event.events.movement;

import me.earth.earthhack.api.event.events.Event;

/**
 * Allows you to cancel EntityPlayerSP - pushOutOfBlocks.
 */
public class BlockPushEvent extends Event
{

}
