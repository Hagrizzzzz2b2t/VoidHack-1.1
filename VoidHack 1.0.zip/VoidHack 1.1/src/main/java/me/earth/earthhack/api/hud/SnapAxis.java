package me.earth.earthhack.api.hud;

// TODO: more axis once i find a good solution for snapping
public enum SnapAxis
{
    TOP,
    BOTTOM,
    NONE
}
