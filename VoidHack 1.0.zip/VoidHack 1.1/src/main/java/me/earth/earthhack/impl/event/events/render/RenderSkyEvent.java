package me.earth.earthhack.impl.event.events.render;

public class RenderSkyEvent {}
