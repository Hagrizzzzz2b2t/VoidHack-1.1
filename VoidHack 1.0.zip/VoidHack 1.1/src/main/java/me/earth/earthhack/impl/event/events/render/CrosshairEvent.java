package me.earth.earthhack.impl.event.events.render;

import me.earth.earthhack.api.event.events.Event;

/**
 * @author Gerald
 * @since 6/17/2021
 **/

public class CrosshairEvent extends Event {

}
