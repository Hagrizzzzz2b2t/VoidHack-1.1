package me.earth.earthhack.impl.event.events.render;

import me.earth.earthhack.api.event.events.Event;

/**
 * Fired when you are in a block and the
 * suffocation overlay is rendered.
 */
public class SuffocationEvent extends Event
{

}
