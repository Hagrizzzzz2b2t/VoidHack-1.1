package me.earth.earthhack.impl.event.events.client;

/**
 * Fired after Modules have been initialized, but
 * before a config has been applied. This allows us to
 * add Settings before the config is loaded.
 */
public class PostInitEvent
{

}
