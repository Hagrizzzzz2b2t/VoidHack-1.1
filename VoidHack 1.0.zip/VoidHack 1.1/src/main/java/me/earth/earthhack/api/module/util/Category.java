package me.earth.earthhack.api.module.util;

public enum Category
{
    Combat,
    Misc,
    Render,
    Movement,
    Player,
    Client
    // Hud // TODO: idk
}
