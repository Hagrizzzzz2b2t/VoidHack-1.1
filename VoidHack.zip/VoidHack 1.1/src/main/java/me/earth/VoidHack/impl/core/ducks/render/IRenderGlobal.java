package me.earth.earthhack.impl.core.ducks.render;

import java.util.List;

public interface IRenderGlobal
{

    List<Object> getRenderInfoList();

}
