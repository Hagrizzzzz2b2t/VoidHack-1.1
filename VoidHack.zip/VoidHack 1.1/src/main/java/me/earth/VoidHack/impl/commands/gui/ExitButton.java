package me.earth.earthhack.impl.commands.gui;

import me.earth.earthhack.impl.gui.buttons.SimpleButton;

public class ExitButton extends SimpleButton
{
    public ExitButton(int buttonID, int xPos, int yPos)
    {
        super(buttonID, xPos, yPos, 0, 80, 0, 100);
    }

}
