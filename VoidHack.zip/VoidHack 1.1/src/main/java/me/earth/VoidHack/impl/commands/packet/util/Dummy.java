package me.earth.earthhack.impl.commands.packet.util;

/**
 * This interface groups Dummy Values.
 */
public interface Dummy
{
    default boolean isDummy()
    {
        return true;
    }
}
