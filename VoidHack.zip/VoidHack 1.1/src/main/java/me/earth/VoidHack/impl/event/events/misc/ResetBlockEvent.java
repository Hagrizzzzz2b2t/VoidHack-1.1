package me.earth.earthhack.impl.event.events.misc;

import me.earth.earthhack.api.event.events.Event;

public class ResetBlockEvent extends Event
{

}
