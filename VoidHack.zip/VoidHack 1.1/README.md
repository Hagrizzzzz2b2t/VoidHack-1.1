# 3arthh4ck
The real phobos recode. Brought to you by oHareDaBoss himself.

released because grin is a big b word. very uncool of what he did.
not swag.
ohare.cc config provided because ohare.cc is the best server in mc.
https://www.youtube.com/watch?v=xUyx8BdJ6JE
the gui isn't bound by default so bind it with +bind clickgui rshift (+ is the default command prefix)
every client bouta get a recode
